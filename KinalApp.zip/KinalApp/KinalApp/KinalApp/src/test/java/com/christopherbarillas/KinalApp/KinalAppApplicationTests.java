package com.christopherbarillas.KinalApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KinalAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
